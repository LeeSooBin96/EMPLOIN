#ifndef COMPANY_PAGE_H_
#define COMPANY_PAGE_H_

class CompanyPage
{
public:
    //기업 정보 페이지 메인 프로세스
    void ProcessCompany(int);
};
#endif